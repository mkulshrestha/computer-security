#include<stdio.h>
#include<string.h>
/* 50291406 */
int main(int argc, char** argv)
{
	char buffer[7]; //as specified in the experiment
	strcpy(buffer, argv[1]);
	return 0;
}
